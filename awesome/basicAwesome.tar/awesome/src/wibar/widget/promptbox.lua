--{{{ Creates prompt box widget
function getPromptbox ()
  promptbox = awful.widget.prompt()
  return promptbox
end
--}}}