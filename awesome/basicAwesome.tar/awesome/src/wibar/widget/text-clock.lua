--{{{ creates a modern text clock widget
  function getTextClock () 
    textClock = wibox.widget.textclock()
    return textClock
  end
--}}}