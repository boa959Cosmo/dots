--{{{ Creates layout box widget
function getLayoutbox (currentScreen)
  layoutbox = awful.widget.layoutbox(currentScreen)
  return layoutbox
end
--}}}