--{{{ Keyboard map indicator and switcher
  function getKeyboardLayout ()
    keyboardLayout = awful.widget.keyboardlayout()
    return keyboardLayout
  end
--}}}